package com.example.tugas2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.tugas2.ui.theme.Tugas2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Tugas2Theme {
                CalculatorApp()
            }
        }
    }
}

@Composable
fun CalculatorApp() {
    var number1 by remember { mutableStateOf("") }
    var number2 by remember { mutableStateOf("") }
    var selectedOperation by remember { mutableStateOf("+") }
    var result by remember { mutableStateOf<String?>(null) }

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(16.dp)
                .padding(innerPadding)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Input number 1
            OutlinedTextField(
                value = number1,
                onValueChange = { number1 = it },
                label = { Text("Masukkan angka pertama") },
                modifier = Modifier.fillMaxWidth()
            )

            // Input number 2
            OutlinedTextField(
                value = number2,
                onValueChange = { number2 = it },
                label = { Text("Masukkan angka kedua") },
                modifier = Modifier.fillMaxWidth()
            )

            // Radio buttons for operations
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RadioButtonWithText(text = "+", selected = selectedOperation == "+") {
                    selectedOperation = "+"
                }
                RadioButtonWithText(text = "-", selected = selectedOperation == "-") {
                    selectedOperation = "-"
                }
                RadioButtonWithText(text = "*", selected = selectedOperation == "*") {
                    selectedOperation = "*"
                }
                RadioButtonWithText(text = "/", selected = selectedOperation == "/") {
                    selectedOperation = "/"
                }
            }

            // Button to calculate
            Button(onClick = {
                val num1 = number1.toDoubleOrNull()
                val num2 = number2.toDoubleOrNull()

                if (num1 != null && num2 != null) {
                    result = when (selectedOperation) {
                        "+" -> (num1 + num2).toString()
                        "-" -> (num1 - num2).toString()
                        "*" -> (num1 * num2).toString()
                        "/" -> if (num2 != 0.0) (num1 / num2).toString() else "Tidak dapat membagi dengan 0"
                        else -> "Operasi tidak valid"
                    }
                } else {
                    result = "Input tidak valid"
                }
            }) {
                Text("Hitung")
            }

            // Display result
            result?.let {
                Text(
                    text = "Hasil: $it",
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Display NIM and Name
            Text(text = "NIM: 225150407111091", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Nama: Jeam Akbar Katigo Alfajri", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun RadioButtonWithText(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(text = text)
    }
}

@Preview(showBackground = true)
@Composable
fun CalculatorAppPreview() {
    Tugas2Theme {
        CalculatorApp()
    }
}
